const nodemailer = require('nodemailer');

let transporter;

async function createTransporter() {

    const testAccount =
        await nodemailer.createTestAccount();

    transporter = nodemailer.createTransport({

        host: 'smtp.ethereal.email',

        port: 587,

        secure: false,

        auth: {
            user: testAccount.user,
            pass: testAccount.pass
        }
    });
}

async function sendOTP(email, code) {

    if (!transporter) {
        await createTransporter();
    }

    const info = await transporter.sendMail({

        from: '"VIPERDBOX" <test@viperdbox.com>',

        to: email,

        subject: 'Código OTP',

        html: `
            <h1>${code}</h1>
            <p>Tu código de verificación</p>
        `
    });

    console.log('Correo enviado');

    console.log(
        nodemailer.getTestMessageUrl(info)
    );
}

module.exports = { sendOTP };