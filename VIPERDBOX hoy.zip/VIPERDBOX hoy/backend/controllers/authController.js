const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const db = require('../config/database');
const { sendOTP } = require('../services/emailService');

exports.register = async (req, res) => {

  const { name, email, password } = req.body;

  try {

    const existing = await User.findByEmail(email);

    if (existing) {
      return res.status(400).json({
        error: 'El email ya está registrado'
      });
    }

    const hashed = await bcrypt.hash(password, 10);

    const userId = await User.create({
      name,
      email,
      password: hashed
    });

    const token = jwt.sign(
      { id: userId },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(201).json({
      token,
      user: {
        id: userId,
        name,
        email
      }
    });

  } catch (err) {

    console.error(err);

    res.status(500).json({
      error: 'Error en el servidor'
    });

  }
};

exports.login = async (req, res) => {

  const { email, password } = req.body;

  try {

    const user = await User.findByEmail(email);

    if (!user) {
      return res.status(401).json({
        error: 'Credenciales inválidas'
      });
    }

    const valid = await bcrypt.compare(
      password,
      user.password
    );

    if (!valid) {
      return res.status(401).json({
        error: 'Credenciales inválidas'
      });
    }

    // GENERAR OTP
    const otp = Math.floor(
      100000 + Math.random() * 900000
    ).toString();

    // EXPIRACIÓN 5 MINUTOS
    const expires = new Date(
      Date.now() + 5 * 60 * 1000
    );

    // GUARDAR OTP EN BD
    await db.query(
      `UPDATE users
       SET otp_code = $1,
           otp_expires = $2
       WHERE id = $3`,
      [otp, expires, user.id]
    );

    // ENVIAR CORREO
    await sendOTP(user.email, otp);

    // RESPUESTA PARA 2FA
    res.json({
      requires2FA: true,
      userId: user.id
    });

  } catch (err) {

    console.error(err);

    res.status(500).json({
      error: 'Error en el servidor'
    });

  }
};

exports.verifyOTP = async (req, res) => {

  const { userId, code } = req.body;

  try {

    const result = await db.query(
      'SELECT * FROM users WHERE id = $1',
      [userId]
    );

    const user = result.rows[0];

    if (!user) {
      return res.status(404).json({
        error: 'Usuario no encontrado'
      });
    }

    if (user.otp_code !== code) {
      return res.status(401).json({
        error: 'Código incorrecto'
      });
    }

    if (new Date() > user.otp_expires) {
      return res.status(401).json({
        error: 'Código expirado'
      });
    }

    // CREAR TOKEN FINAL
    const token = jwt.sign(
      { id: user.id },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email
      }
    });

  } catch (err) {

    console.error(err);

    res.status(500).json({
      error: 'Error en el servidor'
    });

  }
};